/**
 * @file
 * Global utilities.
 *
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.mytheme = {
    attach: function (context, settings) {

    }
  };

})(Drupal);
;
